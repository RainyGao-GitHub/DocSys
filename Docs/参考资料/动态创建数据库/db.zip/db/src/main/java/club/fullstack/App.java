package club.fullstack;

import java.io.*;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;

/**
 * Hello world!
 *
 */
public class App 
{

    /**
     * 同步配置文件
     * 如果运行目录下有配置文件，则使用运行目录的
     * 如果运行目录没有，则使用默认配置，并释放到运行目录
     */
    public Properties syncConfig() throws IOException {
        String userDir = System.getProperty("user.dir");
        File configFile = new File(userDir, "db.config.properties");
        Properties config = new Properties();
        if( ! configFile.exists() ){
            InputStream is = App.class.getClassLoader().getResourceAsStream("db.config.properties");
            byte[] content = new byte[ is.available() ];
            is.read( content );
            config.load( new StringReader(new String(content) ) );
            configFile.createNewFile();
            OutputStream out = new FileOutputStream(configFile);
            out.write(content);
            out.close();
        } else {
            InputStream is = new FileInputStream(configFile);
            config.load( is );
        }
        return config;
    }



    public void createDatabaseIfNotExit(Properties config) throws SQLException {

        String url = String.format("jdbc:mysql://%s:%s/%s",

                config.getProperty("ip"),
                config.getProperty("port"),
                "mysql"

                );
        url += "?useSSL=false&serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=UTF-8";

        try (
                Connection conn = DriverManager.getConnection(
                url,
                config.getProperty("user"),
                config.getProperty("pwd"));

                PreparedStatement ps = conn.prepareStatement("SHOW DATABASES");
        ) {
            List<String> dbs = new ArrayList();
            ResultSet rs = ps.executeQuery();
            while ( rs.next() ){
                String name = rs.getString("Database");
                dbs.add( name );
            }

            String db = config.getProperty("db");
            if ( !dbs.contains( db ) ){

                String dbSQL = "CREATE DATABASE `" + db + "` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci";
                try ( PreparedStatement psc = conn.prepareStatement(dbSQL) ){
                    psc.execute();
                    System.out.println("数据库【" + db + "】已创建");
                }

            }else {
                System.out.println("数据库【" + db + "】已存在");
            }

        }

    }

    public void createTableIfNotExit(Properties config) throws SQLException {
        String url = String.format("jdbc:mysql://%s:%s/%s",

                config.getProperty("ip"),
                config.getProperty("port"),
                config.getProperty("db")

        );
        url += "?useSSL=false&serverTimezone=GMT%2B8&useUnicode=true&characterEncoding=UTF-8";

        try (
                Connection conn = DriverManager.getConnection(
                        url,
                        config.getProperty("user"),
                        config.getProperty("pwd"));

                PreparedStatement ps = conn.prepareStatement("CREATE TABLE IF NOT EXISTS `runoob_tbl`(\n" +
                        "   `runoob_id` INT UNSIGNED AUTO_INCREMENT,\n" +
                        "   `runoob_title` VARCHAR(100) NOT NULL,\n" +
                        "   `runoob_author` VARCHAR(40) NOT NULL,\n" +
                        "   `submission_date` DATE,\n" +
                        "   PRIMARY KEY ( `runoob_id` )\n" +
                        ")ENGINE=InnoDB DEFAULT CHARSET=utf8;");
        ) {
            ps.execute();
        }
    }


    public void useDatabase(Properties config){
        //
    }

    public static void main( String[] args ) throws IOException, SQLException, InterruptedException {
        App app = new App();
        Properties config = app.syncConfig();
        app.createDatabaseIfNotExit( config );
        app.createTableIfNotExit( config );
        app.useDatabase( config );

        // 查看输出
        Thread.sleep(10 * 1000);

    }
}
